import { useState, useEffect } from "react";
import { AreaChart, Area, XAxis, YAxis, ResponsiveContainer, Tooltip } from "recharts";
import {
  Home, Clock, User, ChevronRight, Lock,
  Upload, Check, AlertTriangle, ArrowLeft,
  Target, Zap, Activity, Camera,
  Trash2, Settings, Star, Info, Shield,
  TrendingUp, TrendingDown, Minus
} from "lucide-react";

type Screen =
  | "splash"
  | "dashboard"
  | "shooting-guide"
  | "video-upload"
  | "processing"
  | "results"
  | "history"
  | "profile";

// ─── DESIGN TOKENS ──────────────────────────────────────────────────────────
const G = {
  bg: "#06091A",
  bgDeep: "#040610",
  card: "#0C1126",
  card2: "#111829",
  card3: "#16203A",
  green: "#2EE86B",
  greenDim: "rgba(46,232,107,0.12)",
  greenBorder: "rgba(46,232,107,0.25)",
  white: "#EEF2FF",
  whiteDim: "#B8C4DD",
  muted: "#6B7A99",
  border: "rgba(255,255,255,0.07)",
  borderMid: "rgba(255,255,255,0.12)",
  amber: "#F59E0B",
  blue: "#60A5FA",
  red: "#FF4757",
  purple: "#A78BFA",
  navy: "#06091A",
};

// ─── UTILITY COMPONENTS ──────────────────────────────────────────────────────

function FieldGrid({ opacity = 0.035 }: { opacity?: number }) {
  return (
    <svg
      style={{ opacity, pointerEvents: "none" }}
      className="absolute inset-0 w-full h-full"
      xmlns="http://www.w3.org/2000/svg"
    >
      <defs>
        <pattern id="fg" x="0" y="0" width="40" height="40" patternUnits="userSpaceOnUse">
          <path d="M 40 0 L 0 0 0 40" fill="none" stroke={G.green} strokeWidth="0.5" />
        </pattern>
      </defs>
      <rect width="100%" height="100%" fill="url(#fg)" />
    </svg>
  );
}

function GlowOrb({ top, right, size = 240, opacity = 0.08 }: {
  top?: string; right?: string; size?: number; opacity?: number;
}) {
  return (
    <div className="absolute pointer-events-none rounded-full"
      style={{
        top, right,
        width: size, height: size,
        background: `radial-gradient(circle, ${G.green} 0%, transparent 70%)`,
        opacity,
        transform: "translate(40%, -40%)",
      }} />
  );
}

function ScoreRing({ score, size = 136 }: { score: number; size?: number }) {
  const stroke = 9;
  const r = (size - stroke * 2) / 2;
  const circ = 2 * Math.PI * r;
  const arc = (score / 100) * circ;
  const cx = size / 2;
  const cy = size / 2;
  return (
    <svg width={size} height={size}>
      <circle cx={cx} cy={cy} r={r} fill="none" stroke={G.card3} strokeWidth={stroke} />
      <circle
        cx={cx} cy={cy} r={r} fill="none"
        stroke={G.green} strokeWidth={stroke}
        strokeDasharray={`${arc} ${circ}`}
        strokeLinecap="round"
        transform={`rotate(-90 ${cx} ${cy})`}
        style={{ filter: `drop-shadow(0 0 10px ${G.green}80)` }}
      />
      <text x={cx} y={cy - 9} textAnchor="middle" fill={G.white}
        fontSize="30" fontWeight="800" fontFamily="'Barlow Condensed', sans-serif">
        {score}
      </text>
      <text x={cx} y={cy + 12} textAnchor="middle" fill={G.muted}
        fontSize="11" fontFamily="'DM Sans', sans-serif">
        out of 100
      </text>
    </svg>
  );
}

function MiniBar({ value, color = G.green }: { value: number; color?: string }) {
  return (
    <div className="h-1.5 rounded-full overflow-hidden" style={{ background: G.card3 }}>
      <div className="h-full rounded-full"
        style={{ width: `${value}%`, background: color, boxShadow: `0 0 6px ${color}80` }} />
    </div>
  );
}

function Chip({ label, color = G.green, bg }: { label: string; color?: string; bg?: string }) {
  return (
    <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-[10px] font-bold tracking-wide uppercase"
      style={{ color, background: bg ?? `${color}18`, border: `1px solid ${color}30` }}>
      {label}
    </span>
  );
}

function NavBar({ active, onNav }: { active: Screen; onNav: (s: Screen) => void }) {
  const items: { id: Screen; icon: typeof Home; label: string }[] = [
    { id: "dashboard", icon: Home, label: "Home" },
    { id: "shooting-guide", icon: Target, label: "Analyze" },
    { id: "history", icon: Clock, label: "History" },
    { id: "profile", icon: User, label: "Profile" },
  ];
  return (
    <div className="flex items-center justify-around py-3"
      style={{ background: G.card, borderTop: `1px solid ${G.border}` }}>
      {items.map(({ id, icon: Icon, label }) => {
        const on = active === id || (active === "shooting-guide" && id === "shooting-guide")
          || (active === "video-upload" && id === "shooting-guide")
          || (active === "processing" && id === "shooting-guide")
          || (active === "results" && id === "shooting-guide");
        return (
          <button key={id} onClick={() => onNav(id)}
            className="flex flex-col items-center gap-1 px-4 transition-all">
            <Icon size={20} style={{ color: on ? G.green : G.muted }} />
            <span className="text-[10px] font-semibold tracking-wide"
              style={{ color: on ? G.green : G.muted, fontFamily: "'DM Sans', sans-serif" }}>
              {label}
            </span>
          </button>
        );
      })}
    </div>
  );
}

function BackHeader({ title, sub, onBack }: { title: string; sub?: string; onBack: () => void }) {
  return (
    <div className="flex items-center gap-3 px-5 pt-14 pb-4">
      <button onClick={onBack}
        className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0"
        style={{ background: G.card2, border: `1px solid ${G.border}` }}>
        <ArrowLeft size={17} color={G.whiteDim} />
      </button>
      <div>
        <h1 className="text-xl font-black tracking-wide uppercase leading-tight"
          style={{ fontFamily: "'Barlow Condensed', sans-serif", color: G.white }}>
          {title}
        </h1>
        {sub && <p className="text-[11px] mt-0.5" style={{ color: G.muted }}>{sub}</p>}
      </div>
    </div>
  );
}

// ─── SCREENS ─────────────────────────────────────────────────────────────────

function SplashScreen({ go }: { go: (s: Screen) => void }) {
  return (
    <div className="relative flex flex-col h-full overflow-hidden"
      style={{ background: `linear-gradient(165deg, #0B1430 0%, ${G.bg} 55%)` }}>
      <FieldGrid opacity={0.05} />
      <GlowOrb top="0" right="0" size={300} opacity={0.12} />

      <div className="relative flex-1 flex flex-col items-center justify-center px-7 gap-7">
        {/* Logo */}
        <div className="relative w-20 h-20 rounded-[22px] flex items-center justify-center"
          style={{
            background: `linear-gradient(135deg, #162040 0%, #0C1126 100%)`,
            border: `1.5px solid ${G.greenBorder}`,
            boxShadow: `0 0 40px ${G.green}18, 0 8px 32px rgba(0,0,0,0.5)`,
          }}>
          {/* Football icon */}
          <svg width="44" height="44" viewBox="0 0 44 44" fill="none">
            <circle cx="22" cy="22" r="20" stroke={G.green} strokeWidth="1.5" />
            <circle cx="22" cy="22" r="20" fill={G.greenDim} />
            <polygon points="22,12 27,16.5 25.2,23 18.8,23 17,16.5" fill={G.green} opacity="0.95" />
            <line x1="22" y1="2" x2="22" y2="12" stroke={G.green} strokeWidth="1.3" />
            <line x1="22" y1="32" x2="22" y2="42" stroke={G.green} strokeWidth="1.3" />
            <line x1="17" y1="16.5" x2="7" y2="12" stroke={G.green} strokeWidth="1.3" />
            <line x1="27" y1="16.5" x2="37" y2="12" stroke={G.green} strokeWidth="1.3" />
            <line x1="18.8" y1="23" x2="10" y2="34" stroke={G.green} strokeWidth="1.3" />
            <line x1="25.2" y1="23" x2="34" y2="34" stroke={G.green} strokeWidth="1.3" />
          </svg>
        </div>

        {/* Wordmark */}
        <div className="text-center">
          <h1 className="text-[46px] font-black tracking-[0.06em] uppercase leading-none"
            style={{ fontFamily: "'Barlow Condensed', sans-serif", color: G.white }}>
            KickAI
          </h1>
          <div className="text-[22px] font-semibold tracking-[0.18em] uppercase -mt-1"
            style={{ fontFamily: "'Barlow Condensed', sans-serif", color: G.green }}>
            Coach
          </div>
          <p className="text-sm tracking-[0.12em] mt-4"
            style={{ color: G.muted, fontFamily: "'DM Sans', sans-serif" }}>
            Analyze your shot. Train smarter.
          </p>
        </div>

        {/* Feature chips */}
        <div className="flex flex-wrap gap-2 justify-center">
          {["AI Technique Feedback", "Progress Tracking", "Drill Recommendations"].map(f => (
            <span key={f} className="px-3 py-1 rounded-full text-[10px] font-semibold tracking-wide"
              style={{ background: G.card2, color: G.whiteDim, border: `1px solid ${G.border}` }}>
              {f}
            </span>
          ))}
        </div>
      </div>

      {/* Buttons */}
      <div className="relative px-6 pb-12 space-y-3">
        <button onClick={() => go("dashboard")}
          className="w-full py-[17px] rounded-2xl font-black text-[16px] tracking-[0.12em] uppercase transition-all active:scale-[0.97]"
          style={{
            background: `linear-gradient(90deg, #2EE86B 0%, #1DC959 100%)`,
            color: G.bg,
            fontFamily: "'Barlow Condensed', sans-serif",
            boxShadow: `0 6px 32px ${G.green}40`,
          }}>
          Get Started
        </button>
        <button onClick={() => go("history")}
          className="w-full py-[17px] rounded-2xl font-bold text-[16px] tracking-[0.12em] uppercase transition-all active:scale-[0.97]"
          style={{
            background: "transparent",
            color: G.whiteDim,
            fontFamily: "'Barlow Condensed', sans-serif",
            border: `1.5px solid ${G.border}`,
          }}>
          View History
        </button>
        <p className="text-center text-[10px] pt-1" style={{ color: G.muted }}>
          Shooting Analysis · MVP v1.0
        </p>
      </div>
    </div>
  );
}

function DashboardScreen({ go }: { go: (s: Screen) => void }) {
  const statsRow = [
    { label: "Latest", value: "76", sub: "/100", color: G.green },
    { label: "Best", value: "84", sub: "/100", color: G.blue },
    { label: "Sessions", value: "6", sub: "total", color: G.amber },
  ];

  const recentSessions = [
    { score: 76, date: "Today", delta: +7 },
    { score: 69, date: "Yesterday", delta: -3 },
    { score: 72, date: "Mon", delta: +4 },
  ];

  return (
    <div className="flex flex-col h-full">
      <div className="flex-1 overflow-y-auto" style={{ scrollbarWidth: "none" }}>
        {/* Header */}
        <div className="relative overflow-hidden px-5 pt-14 pb-7"
          style={{ background: `linear-gradient(165deg, #0B1430 0%, ${G.bg} 100%)` }}>
          <FieldGrid opacity={0.04} />
          <GlowOrb top="0" right="0" size={200} opacity={0.1} />
          <div className="relative">
            <p className="text-[11px] tracking-[0.18em] uppercase font-semibold"
              style={{ color: G.green, fontFamily: "'DM Sans', sans-serif" }}>
              Shooting Analysis
            </p>
            <h2 className="text-[30px] font-black uppercase leading-tight mt-1"
              style={{ fontFamily: "'Barlow Condensed', sans-serif", color: G.white }}>
              Ready to improve<br />your technique?
            </h2>
          </div>
        </div>

        <div className="px-5 space-y-4 pb-6 mt-4">
          {/* Stats strip */}
          <div className="grid grid-cols-3 gap-2.5">
            {statsRow.map(({ label, value, sub, color }) => (
              <div key={label} className="rounded-2xl p-3.5 text-center"
                style={{ background: G.card, border: `1px solid ${G.border}` }}>
                <div className="text-2xl font-black leading-none"
                  style={{ fontFamily: "'Barlow Condensed', sans-serif", color }}>
                  {value}<span className="text-sm" style={{ color: G.muted }}>{sub}</span>
                </div>
                <div className="text-[9px] tracking-widest uppercase mt-1.5" style={{ color: G.muted }}>
                  {label}
                </div>
              </div>
            ))}
          </div>

          {/* Primary CTA */}
          <button onClick={() => go("shooting-guide")}
            className="w-full rounded-2xl overflow-hidden relative transition-all active:scale-[0.98]"
            style={{ boxShadow: `0 8px 40px ${G.green}18` }}>
            <div className="relative p-5"
              style={{
                background: `linear-gradient(135deg, #0C1E40 0%, #091628 100%)`,
                border: `1.5px solid ${G.greenBorder}`,
                borderRadius: 16,
              }}>
              <FieldGrid opacity={0.07} />
              <div className="relative flex items-center justify-between gap-3">
                <div className="text-left">
                  <div className="text-[10px] tracking-[0.2em] uppercase font-bold mb-1.5"
                    style={{ color: G.green }}>
                    New Session
                  </div>
                  <div className="text-[26px] font-black uppercase leading-tight"
                    style={{ fontFamily: "'Barlow Condensed', sans-serif", color: G.white }}>
                    Analyze<br />Shooting
                  </div>
                  <div className="text-[11px] mt-1.5" style={{ color: G.muted }}>
                    Upload a video · Get AI technique feedback
                  </div>
                </div>
                <div className="w-14 h-14 rounded-2xl flex items-center justify-center flex-shrink-0"
                  style={{
                    background: `linear-gradient(135deg, ${G.green} 0%, #1DC959 100%)`,
                    boxShadow: `0 4px 20px ${G.green}50`,
                  }}>
                  <Target size={26} color={G.bg} strokeWidth={2.5} />
                </div>
              </div>
            </div>
          </button>

          {/* Recent sessions */}
          {recentSessions.length > 0 && (
            <div>
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-[13px] font-black uppercase tracking-widest"
                  style={{ fontFamily: "'Barlow Condensed', sans-serif", color: G.white }}>
                  Recent Sessions
                </h3>
                <button onClick={() => go("history")}
                  className="text-[11px] font-semibold" style={{ color: G.green }}>
                  See All
                </button>
              </div>
              <div className="space-y-2">
                {recentSessions.map(({ score, date, delta }, i) => (
                  <div key={i} className="flex items-center gap-3 rounded-xl px-4 py-3"
                    style={{ background: G.card, border: `1px solid ${G.border}` }}>
                    <div className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0"
                      style={{ background: G.greenDim }}>
                      <span className="text-base">⚽</span>
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-baseline gap-2">
                        <span className="text-[15px] font-black"
                          style={{ fontFamily: "'Barlow Condensed', sans-serif", color: G.white }}>
                          {score}<span className="text-xs font-normal" style={{ color: G.muted }}>/100</span>
                        </span>
                        <span className="text-[10px] font-bold"
                          style={{ color: delta > 0 ? G.green : G.red }}>
                          {delta > 0 ? `+${delta}` : delta}
                        </span>
                      </div>
                      <div className="text-[11px]" style={{ color: G.muted }}>Shooting · {date}</div>
                    </div>
                    <ChevronRight size={14} color={G.muted} />
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Locked modules notice */}
          <div className="rounded-xl p-4 flex items-center gap-3"
            style={{ background: G.card, border: `1px solid ${G.border}` }}>
            <Lock size={16} color={G.muted} className="flex-shrink-0" />
            <div>
              <p className="text-[12px] font-semibold" style={{ color: G.whiteDim }}>
                Dribbling, Passing & First Touch modules coming soon
              </p>
              <p className="text-[10px] mt-0.5" style={{ color: G.muted }}>
                Focus on shooting while we build the rest
              </p>
            </div>
          </div>
        </div>
      </div>
      <NavBar active="dashboard" onNav={go} />
    </div>
  );
}

function ShootingGuideScreen({ go }: { go: (s: Screen) => void }) {
  const rules: { icon: string; title: string; detail: string }[] = [
    { icon: "5️⃣", title: "5 shots in one video", detail: "Perform all 5 shots without stopping the recording." },
    { icon: "⏸️", title: "Stationary ball before each shot", detail: "Place the ball still on the ground before approaching." },
    { icon: "👤", title: "Full body visible", detail: "Your entire body must stay in frame throughout every shot." },
    { icon: "⚽", title: "Ball and goal/target visible", detail: "Both the ball and the target must be in frame at all times." },
    { icon: "📷", title: "Fixed camera", detail: "Mount or prop your phone — no one should hold it during recording." },
    { icon: "📐", title: "Side or 45° angle only", detail: "Camera must face the shooting line from the side or diagonal." },
    { icon: "⏱", title: "Video: 10–25 seconds", detail: "Longer or shorter videos cannot be processed reliably." },
    { icon: "🧍", title: "One player only", detail: "No other players in the frame during the drill." },
  ];

  return (
    <div className="flex flex-col h-full">
      <BackHeader title="Recording Guide" sub="Read carefully before you record" onBack={() => go("dashboard")} />
      <div className="flex-1 overflow-y-auto px-5 pb-6 space-y-3" style={{ scrollbarWidth: "none" }}>

        {/* Diagram */}
        <div className="relative rounded-2xl overflow-hidden"
          style={{ background: G.card, border: `1px solid ${G.border}`, height: 180 }}>
          <FieldGrid opacity={0.07} />
          <svg className="absolute inset-0 w-full h-full" viewBox="0 0 360 180" preserveAspectRatio="xMidYMid meet">
            {/* Field rectangle */}
            <rect x="20" y="20" width="320" height="140" fill="none" stroke={G.green} strokeWidth="0.8" opacity="0.2" rx="4" />
            {/* Center line */}
            <line x1="180" y1="20" x2="180" y2="160" stroke={G.green} strokeWidth="0.6" strokeDasharray="4 4" opacity="0.2" />

            {/* Goal posts */}
            <rect x="60" y="50" width="48" height="5" rx="2" fill={G.green} opacity="0.7" />
            <rect x="60" y="50" width="4" height="48" rx="2" fill={G.green} opacity="0.5" />
            <rect x="104" y="50" width="4" height="48" rx="2" fill={G.green} opacity="0.5" />

            {/* Ball */}
            <circle cx="232" cy="130" r="8" fill={G.white} opacity="0.85" />
            <circle cx="232" cy="130" r="8" fill="none" stroke={G.muted} strokeWidth="0.8" />
            <circle cx="232" cy="130" r="3" fill={G.card} opacity="0.5" />

            {/* Player silhouette */}
            <circle cx="250" cy="104" r="6" fill={G.whiteDim} opacity="0.75" />
            <rect x="244" y="111" width="12" height="22" rx="3" fill={G.whiteDim} opacity="0.65" />
            <rect x="244" y="129" width="5" height="18" rx="2.5" fill={G.whiteDim} opacity="0.55" />
            <rect x="250" y="129" width="5" height="18" rx="2.5" fill={G.whiteDim} opacity="0.55" />
            <rect x="237" y="113" width="6" height="16" rx="3" fill={G.whiteDim} opacity="0.45" />
            <rect x="257" y="113" width="6" height="16" rx="3" fill={G.whiteDim} opacity="0.45" />

            {/* Shot arc */}
            <path d="M 232 130 Q 160 80 84 73" stroke={G.green} strokeWidth="1.5" fill="none"
              strokeDasharray="5 3" opacity="0.55" />
            <polygon points="84,68 78,76 90,76" fill={G.green} opacity="0.55" />

            {/* Camera */}
            <rect x="288" y="118" width="40" height="28" rx="5" fill={G.card3} stroke={G.greenBorder} strokeWidth="1" />
            <circle cx="304" cy="132" r="7" fill={G.green} opacity="0.3" />
            <circle cx="304" cy="132" r="4" fill={G.green} opacity="0.6" />
            <rect x="326" y="126" width="4" height="12" rx="2" fill={G.muted} opacity="0.5" />

            {/* Camera angle label */}
            <text x="288" y="112" fill={G.green} fontSize="9" opacity="0.7" fontFamily="'DM Sans', sans-serif">45° / Side</text>

            {/* Labels */}
            <text x="82" y="44" fill={G.green} fontSize="9" opacity="0.7" textAnchor="middle" fontFamily="'DM Sans', sans-serif">Goal</text>
            <text x="232" y="152" fill={G.whiteDim} fontSize="9" opacity="0.7" textAnchor="middle" fontFamily="'DM Sans', sans-serif">Ball</text>
          </svg>
        </div>

        {/* Rules */}
        <div className="space-y-2">
          {rules.map(({ icon, title, detail }) => (
            <div key={title} className="flex items-start gap-3.5 rounded-xl px-4 py-3.5"
              style={{ background: G.card, border: `1px solid ${G.border}` }}>
              <span className="text-[18px] flex-shrink-0 mt-0.5">{icon}</span>
              <div>
                <p className="text-[13px] font-bold leading-snug" style={{ color: G.white, fontFamily: "'DM Sans', sans-serif" }}>
                  {title}
                </p>
                <p className="text-[11px] mt-0.5 leading-relaxed" style={{ color: G.muted }}>
                  {detail}
                </p>
              </div>
            </div>
          ))}
        </div>

        {/* Warning note */}
        <div className="flex items-start gap-3 rounded-xl px-4 py-3.5"
          style={{ background: `${G.amber}0F`, border: `1px solid ${G.amber}28` }}>
          <AlertTriangle size={15} color={G.amber} className="flex-shrink-0 mt-0.5" />
          <p className="text-[11px] leading-relaxed" style={{ color: `${G.amber}CC` }}>
            Poor video quality, missing body parts, or a moving camera will reduce analysis confidence and may affect scores.
          </p>
        </div>

        <button onClick={() => go("video-upload")}
          className="w-full py-[17px] rounded-2xl font-black text-[16px] tracking-[0.1em] uppercase transition-all active:scale-[0.97]"
          style={{
            background: `linear-gradient(90deg, #2EE86B 0%, #1DC959 100%)`,
            color: G.bg,
            fontFamily: "'Barlow Condensed', sans-serif",
            boxShadow: `0 6px 28px ${G.green}40`,
          }}>
          {"I'm Ready — Upload Video"}
        </button>
      </div>
    </div>
  );
}

function VideoUploadScreen({ go }: { go: (s: Screen) => void }) {
  const [uploaded, setUploaded] = useState(false);
  const [errorType, setErrorType] = useState<null | "long" | "short">(null);

  const checklist = [
    "Full body visible throughout",
    "Ball and goal in frame",
    "Stationary ball before each shot",
    "Fixed camera, side or 45° angle",
    "5 shots performed",
  ];

  return (
    <div className="flex flex-col h-full">
      <BackHeader title="Upload Video" sub="Shooting drill — 5 shots" onBack={() => go("shooting-guide")} />
      <div className="flex-1 overflow-y-auto px-5 pb-6 space-y-4" style={{ scrollbarWidth: "none" }}>

        {/* Drop zone */}
        <div
          onClick={() => { setUploaded(!uploaded); setErrorType(null); }}
          className="relative rounded-2xl flex flex-col items-center justify-center gap-3 cursor-pointer transition-all active:scale-[0.98]"
          style={{
            height: 188,
            background: uploaded ? `${G.green}08` : G.card,
            border: `2px dashed ${uploaded ? G.green : G.border}`,
            borderRadius: 20,
          }}>
          <FieldGrid opacity={uploaded ? 0.06 : 0.03} />
          <div className="relative text-center flex flex-col items-center gap-2">
            {uploaded ? (
              <>
                <div className="w-14 h-14 rounded-full flex items-center justify-center"
                  style={{ background: G.greenDim }}>
                  <Check size={26} color={G.green} strokeWidth={2.5} />
                </div>
                <p className="text-[13px] font-bold" style={{ color: G.green }}>Video ready</p>
                <p className="text-[11px]" style={{ color: G.muted }}>
                  shooting_drill.mp4&nbsp;&nbsp;·&nbsp;&nbsp;18 sec&nbsp;&nbsp;·&nbsp;&nbsp;94 MB
                </p>
              </>
            ) : (
              <>
                <div className="w-14 h-14 rounded-full flex items-center justify-center"
                  style={{ background: G.card2 }}>
                  <Upload size={24} color={G.muted} />
                </div>
                <p className="text-[13px] font-semibold" style={{ color: G.white }}>Tap to select video</p>
                <p className="text-[11px]" style={{ color: G.muted }}>MP4 or MOV · 10–25 seconds</p>
              </>
            )}
          </div>
        </div>

        {/* Buttons */}
        <div className="grid grid-cols-2 gap-3">
          {[
            { icon: Upload, label: "Gallery" },
            { icon: Camera, label: "Camera" },
          ].map(({ icon: Icon, label }) => (
            <button key={label}
              onClick={() => setUploaded(true)}
              className="py-3.5 rounded-xl flex items-center justify-center gap-2 transition-all active:scale-[0.97]"
              style={{ background: G.card, border: `1px solid ${G.border}` }}>
              <Icon size={17} color={G.green} />
              <span className="text-[13px] font-bold" style={{ color: G.white, fontFamily: "'DM Sans', sans-serif" }}>
                {label}
              </span>
            </button>
          ))}
        </div>

        {/* Checklist */}
        <div className="rounded-xl p-4 space-y-2.5" style={{ background: G.card, border: `1px solid ${G.border}` }}>
          <p className="text-[10px] font-black tracking-widest uppercase mb-3" style={{ color: G.muted }}>
            Pre-upload Checklist
          </p>
          {checklist.map((item) => (
            <div key={item} className="flex items-center gap-3">
              <div className="w-4 h-4 rounded-full flex items-center justify-center flex-shrink-0 transition-all"
                style={{
                  background: uploaded ? G.greenDim : G.card2,
                  border: `1.5px solid ${uploaded ? G.green : G.border}`,
                }}>
                {uploaded && <Check size={8} color={G.green} strokeWidth={3} />}
              </div>
              <span className="text-[12px]"
                style={{ color: uploaded ? "#C4F5D4" : G.muted, fontFamily: "'DM Sans', sans-serif" }}>
                {item}
              </span>
            </div>
          ))}
        </div>

        {/* Error state demo */}
        <div className="space-y-2">
          {errorType === "long" && (
            <div className="flex items-start gap-3 rounded-xl px-4 py-3.5"
              style={{ background: `${G.red}0F`, border: `1px solid ${G.red}28` }}>
              <AlertTriangle size={15} color={G.red} className="flex-shrink-0 mt-0.5" />
              <div>
                <p className="text-[13px] font-bold" style={{ color: G.red }}>Video too long</p>
                <p className="text-[11px] mt-0.5" style={{ color: `${G.red}AA` }}>
                  Please upload a video between 10 and 25 seconds. Your video is 38 seconds.
                </p>
              </div>
            </div>
          )}
          {errorType === "short" && (
            <div className="flex items-start gap-3 rounded-xl px-4 py-3.5"
              style={{ background: `${G.red}0F`, border: `1px solid ${G.red}28` }}>
              <AlertTriangle size={15} color={G.red} className="flex-shrink-0 mt-0.5" />
              <div>
                <p className="text-[13px] font-bold" style={{ color: G.red }}>Video too short</p>
                <p className="text-[11px] mt-0.5" style={{ color: `${G.red}AA` }}>
                  Your video is only 6 seconds. We need at least 10 seconds to detect 5 shots.
                </p>
              </div>
            </div>
          )}
          <div className="flex gap-2">
            <button onClick={() => setErrorType("long")}
              className="flex-1 py-2 rounded-lg text-[10px] font-bold tracking-wide transition-all"
              style={{ background: G.card2, color: G.muted, border: `1px solid ${G.border}` }}>
              Preview: Too Long
            </button>
            <button onClick={() => setErrorType("short")}
              className="flex-1 py-2 rounded-lg text-[10px] font-bold tracking-wide transition-all"
              style={{ background: G.card2, color: G.muted, border: `1px solid ${G.border}` }}>
              Preview: Too Short
            </button>
          </div>
        </div>

        {/* Analyze button */}
        <button
          onClick={() => go("processing")}
          className="w-full py-[17px] rounded-2xl font-black text-[16px] tracking-[0.1em] uppercase transition-all active:scale-[0.97]"
          style={{
            background: uploaded
              ? `linear-gradient(90deg, #2EE86B 0%, #1DC959 100%)`
              : G.card2,
            color: uploaded ? G.bg : G.muted,
            fontFamily: "'Barlow Condensed', sans-serif",
            boxShadow: uploaded ? `0 6px 28px ${G.green}40` : "none",
          }}>
          Analyze Video
        </button>
      </div>
    </div>
  );
}

function ProcessingScreen({ go }: { go: (s: Screen) => void }) {
  const [progress, setProgress] = useState(0);
  const steps = [
    "Detecting player body position",
    "Locating ball and goal target",
    "Checking plant foot alignment",
    "Measuring follow-through arc",
    "Scoring shot accuracy",
    "Generating technique feedback",
  ];
  const step = Math.min(Math.floor((progress / 100) * steps.length), steps.length - 1);

  useEffect(() => {
    const t = setInterval(() => {
      setProgress(p => {
        if (p >= 100) { clearInterval(t); setTimeout(() => go("results"), 500); return 100; }
        return p + 1.6;
      });
    }, 70);
    return () => clearInterval(t);
  }, []);

  return (
    <div className="relative flex flex-col items-center justify-center h-full px-6 gap-7"
      style={{ background: `linear-gradient(165deg, #0B1430 0%, ${G.bg} 60%)` }}>
      <FieldGrid opacity={0.04} />
      <GlowOrb top="0" right="0" size={280} opacity={0.09} />

      {/* Pulsing ring */}
      <div className="relative flex items-center justify-center">
        <div className="absolute w-36 h-36 rounded-full animate-ping opacity-[0.07]"
          style={{ background: G.green }} />
        <div className="w-28 h-28 rounded-full flex items-center justify-center relative"
          style={{
            background: G.card,
            border: `1.5px solid ${G.greenBorder}`,
            boxShadow: `0 0 40px ${G.green}25`,
          }}>
          <svg width="50" height="50" viewBox="0 0 50 50" fill="none"
            style={{ animation: "spin 4s linear infinite" }}>
            <circle cx="25" cy="25" r="22" stroke={G.green} strokeWidth="1.5" opacity="0.25" />
            <circle cx="25" cy="25" r="22" stroke={G.green} strokeWidth="1.5"
              strokeDasharray="28 110" strokeLinecap="round" />
          </svg>
          <div className="absolute text-[13px] font-black" style={{ color: G.green, fontFamily: "'Barlow Condensed', sans-serif" }}>
            {Math.round(progress)}%
          </div>
        </div>
      </div>

      {/* Label */}
      <div className="text-center">
        <p className="text-[10px] tracking-[0.22em] uppercase mb-1" style={{ color: G.green }}>AI Analysis Running</p>
        <h2 className="text-[28px] font-black uppercase"
          style={{ fontFamily: "'Barlow Condensed', sans-serif", color: G.white }}>
          Processing Video
        </h2>
        <p className="text-[11px] mt-1" style={{ color: G.muted }}>Usually 15–30 seconds</p>
      </div>

      {/* Steps */}
      <div className="w-full rounded-2xl p-5 space-y-3"
        style={{ background: G.card, border: `1px solid ${G.border}` }}>
        {steps.map((s, i) => {
          const done = i < step;
          const active = i === step;
          return (
            <div key={s} className="flex items-center gap-3">
              <div className="w-5 h-5 rounded-full flex items-center justify-center flex-shrink-0"
                style={{
                  background: done ? G.greenDim : active ? `${G.green}08` : G.card2,
                  border: `1.5px solid ${done ? G.green : active ? `${G.green}50` : G.border}`,
                }}>
                {done
                  ? <Check size={9} color={G.green} strokeWidth={3} />
                  : active
                    ? <div className="w-1.5 h-1.5 rounded-full animate-pulse" style={{ background: G.green }} />
                    : null}
              </div>
              <span className="text-[12px] font-medium transition-colors"
                style={{
                  color: done ? "#C0F0D0" : active ? G.white : G.muted,
                  fontFamily: "'DM Sans', sans-serif",
                }}>
                {s}
              </span>
            </div>
          );
        })}
      </div>

      {/* Bar */}
      <div className="w-full">
        <div className="w-full h-1.5 rounded-full overflow-hidden" style={{ background: G.card2 }}>
          <div className="h-full rounded-full transition-all duration-75"
            style={{
              width: `${progress}%`,
              background: `linear-gradient(90deg, #1DC959 0%, ${G.green} 100%)`,
              boxShadow: `0 0 10px ${G.green}70`,
            }} />
        </div>
      </div>

      <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
    </div>
  );
}

function ResultsScreen({ go, showWarning }: { go: (s: Screen) => void; showWarning?: boolean }) {
  const [warning, setWarning] = useState(showWarning ?? false);

  const subScores: { label: string; score: number; color: string; delta: string }[] = [
    { label: "Approach & Balance", score: 78, color: G.green, delta: "+3" },
    { label: "Plant Foot Position", score: 70, color: G.amber, delta: "+1" },
    { label: "Body Posture", score: 74, color: G.blue, delta: "–" },
    { label: "Contact Mechanics", score: 72, color: G.purple, delta: "+2" },
    { label: "Follow-Through", score: 82, color: G.green, delta: "+5" },
    { label: "Accuracy", score: 80, color: "#34D399", delta: "+4" },
  ];

  const drills = [
    { name: "Plant foot placement drill", reps: "4 × 8 shots", focus: "Position" },
    { name: "Instep contact drill", reps: "3 × 10 shots", focus: "Contact" },
    { name: "Low driven shot practice", reps: "5 sets", focus: "Accuracy" },
    { name: "Weak foot finishing", reps: "3 × 6 shots", focus: "Balance" },
  ];

  return (
    <div className="flex flex-col h-full">
      <div className="px-5 pt-14 pb-2 flex items-center justify-between">
        <div>
          <p className="text-[10px] tracking-[0.18em] uppercase" style={{ color: G.green }}>Session Complete</p>
          <h1 className="text-[22px] font-black uppercase"
            style={{ fontFamily: "'Barlow Condensed', sans-serif", color: G.white }}>
            Analysis Results
          </h1>
        </div>
        <button onClick={() => setWarning(w => !w)}
          className="w-8 h-8 rounded-lg flex items-center justify-center"
          style={{ background: G.card2, border: `1px solid ${G.border}` }}
          title="Toggle quality warning">
          <AlertTriangle size={15} color={warning ? G.amber : G.muted} />
        </button>
      </div>

      <div className="flex-1 overflow-y-auto px-5 pb-6 space-y-4" style={{ scrollbarWidth: "none" }}>

        {/* Quality warning */}
        {warning && (
          <div className="flex items-start gap-3 rounded-xl px-4 py-3.5"
            style={{ background: `${G.amber}0E`, border: `1px solid ${G.amber}30` }}>
            <AlertTriangle size={15} color={G.amber} className="flex-shrink-0 mt-0.5" />
            <p className="text-[12px] leading-relaxed" style={{ color: `${G.amber}DD` }}>
              Some scores may be less reliable because the ball was not clearly visible in every frame.
            </p>
          </div>
        )}

        {/* Score hero */}
        <div className="relative rounded-2xl overflow-hidden p-5"
          style={{
            background: `linear-gradient(135deg, #0C1E40 0%, #091628 100%)`,
            border: `1.5px solid ${G.greenBorder}`,
          }}>
          <FieldGrid opacity={0.06} />
          <div className="relative flex items-center gap-5">
            <ScoreRing score={76} size={130} />
            <div className="flex-1 space-y-3">
              <div>
                <p className="text-[10px] tracking-widest uppercase" style={{ color: G.muted }}>Level</p>
                <Chip label="Intermediate" color={G.amber} />
              </div>
              <div>
                <p className="text-[10px] tracking-widest uppercase mb-1" style={{ color: G.muted }}>AI Confidence</p>
                <div className="flex items-center gap-2">
                  <div className="flex-1 h-1.5 rounded-full overflow-hidden" style={{ background: G.card3 }}>
                    <div className="h-full rounded-full" style={{ width: "82%", background: G.blue }} />
                  </div>
                  <span className="text-[11px] font-bold" style={{ color: G.blue, fontFamily: "'JetBrains Mono', monospace" }}>82%</span>
                </div>
              </div>
              <div>
                <p className="text-[10px] tracking-widest uppercase mb-1" style={{ color: G.muted }}>Video Quality</p>
                <Chip label={warning ? "Fair" : "Good"} color={warning ? G.amber : G.green} />
              </div>
            </div>
          </div>
        </div>

        {/* Sub-scores */}
        <div className="rounded-2xl overflow-hidden"
          style={{ background: G.card, border: `1px solid ${G.border}` }}>
          <div className="px-4 py-3" style={{ borderBottom: `1px solid ${G.border}` }}>
            <p className="text-[11px] font-black tracking-widest uppercase" style={{ color: G.muted }}>
              Technical Breakdown
            </p>
          </div>
          <div className="divide-y" style={{ borderColor: G.border }}>
            {subScores.map(({ label, score, color, delta }) => (
              <div key={label} className="px-4 py-3.5 flex items-center gap-4"
                style={{ borderColor: G.border }}>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between mb-1.5">
                    <span className="text-[12px] font-medium" style={{ color: G.whiteDim }}>{label}</span>
                    <div className="flex items-center gap-2 flex-shrink-0">
                      <span className="text-[10px] font-bold" style={{ color: delta.startsWith("+") ? G.green : G.muted }}>
                        {delta}
                      </span>
                      <span className="text-[14px] font-black"
                        style={{ fontFamily: "'Barlow Condensed', sans-serif", color }}>
                        {score}
                      </span>
                    </div>
                  </div>
                  <MiniBar value={score} color={color} />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* AI Coach Feedback */}
        <div className="rounded-2xl p-5"
          style={{ background: G.greenDim, border: `1px solid ${G.greenBorder}` }}>
          <div className="flex items-center gap-2 mb-3">
            <div className="w-7 h-7 rounded-lg flex items-center justify-center"
              style={{ background: `${G.green}25` }}>
              <Zap size={14} color={G.green} />
            </div>
            <span className="text-[11px] font-black tracking-widest uppercase"
              style={{ fontFamily: "'Barlow Condensed', sans-serif", color: G.green }}>
              AI Coach Feedback
            </span>
          </div>
          <p className="text-[13px] leading-[1.65]"
            style={{ color: "#D4F5DC", fontFamily: "'DM Sans', sans-serif" }}>
            Your follow-through is strong, but your plant foot is slightly too far from the ball. Keep your support foot closer and keep your body over the ball to improve accuracy and add more power to driven shots.
          </p>
          <div className="mt-3 pt-3 flex items-center gap-2"
            style={{ borderTop: `1px solid ${G.greenBorder}` }}>
            <Info size={12} color={G.green} opacity={0.6} />
            <p className="text-[10px]" style={{ color: `${G.green}88` }}>
              Based on 5 shots detected · AI-generated feedback
            </p>
          </div>
        </div>

        {/* Recommended Training */}
        <div className="rounded-2xl overflow-hidden"
          style={{ background: G.card, border: `1px solid ${G.border}` }}>
          <div className="px-4 py-3 flex items-center gap-2" style={{ borderBottom: `1px solid ${G.border}` }}>
            <Activity size={14} color={G.blue} />
            <p className="text-[11px] font-black tracking-widest uppercase" style={{ color: G.muted }}>
              Recommended Training
            </p>
          </div>
          <div className="divide-y" style={{ borderColor: G.border }}>
            {drills.map(({ name, reps, focus }, i) => (
              <div key={name} className="px-4 py-3.5 flex items-center gap-3.5"
                style={{ borderColor: G.border }}>
                <div className="w-7 h-7 rounded-lg flex items-center justify-center flex-shrink-0 text-[12px] font-black"
                  style={{
                    background: G.greenDim,
                    color: G.green,
                    fontFamily: "'JetBrains Mono', monospace",
                  }}>
                  {i + 1}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-[13px] font-semibold" style={{ color: G.white }}>{name}</p>
                  <div className="flex items-center gap-2 mt-0.5">
                    <span className="text-[10px] font-bold"
                      style={{ color: G.green, fontFamily: "'JetBrains Mono', monospace" }}>
                      {reps}
                    </span>
                    <span className="text-[9px] px-1.5 py-0.5 rounded"
                      style={{ background: G.card3, color: G.muted }}>{focus}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Actions */}
        <div className="grid grid-cols-2 gap-3">
          <button onClick={() => go("history")}
            className="py-[15px] rounded-2xl font-black text-[15px] tracking-[0.08em] uppercase transition-all active:scale-[0.97]"
            style={{
              background: `linear-gradient(90deg, #2EE86B 0%, #1DC959 100%)`,
              color: G.bg,
              fontFamily: "'Barlow Condensed', sans-serif",
              boxShadow: `0 4px 20px ${G.green}35`,
            }}>
            Save Result
          </button>
          <button onClick={() => go("shooting-guide")}
            className="py-[15px] rounded-2xl font-black text-[15px] tracking-[0.08em] uppercase transition-all active:scale-[0.97]"
            style={{
              background: G.card,
              color: G.whiteDim,
              fontFamily: "'Barlow Condensed', sans-serif",
              border: `1px solid ${G.border}`,
            }}>
            Try Again
          </button>
        </div>
      </div>
    </div>
  );
}

function HistoryScreen({ go }: { go: (s: Screen) => void }) {
  const [filter, setFilter] = useState("All");
  const filters = ["All", "This Week", "This Month"];

  const sessions = [
    { score: 76, date: "Today, 14:32", delta: +7, label: "Session 6" },
    { score: 69, date: "Yesterday, 10:15", delta: -3, label: "Session 5" },
    { score: 72, date: "Mon 30 Jun", delta: +4, label: "Session 4" },
    { score: 68, date: "Sat 28 Jun", delta: -2, label: "Session 3" },
    { score: 70, date: "Thu 26 Jun", delta: +8, label: "Session 2" },
    { score: 62, date: "Tue 24 Jun", delta: null, label: "Session 1" },
  ];

  const chartData = sessions.slice().reverse().map((s, i) => ({
    label: `S${i + 1}`, score: s.score,
  }));

  const bestScore = Math.max(...sessions.map(s => s.score));
  const avgScore = Math.round(sessions.reduce((a, s) => a + s.score, 0) / sessions.length);
  const latestScore = sessions[0].score;

  const mostImproved = "Follow-Through";

  const CustomTooltip = ({ active, payload }: any) => {
    if (active && payload?.length) {
      return (
        <div className="rounded-xl px-3 py-2" style={{ background: G.card2, border: `1px solid ${G.border}` }}>
          <p className="text-[14px] font-black" style={{ color: G.green, fontFamily: "'Barlow Condensed', sans-serif" }}>
            {payload[0].value}/100
          </p>
        </div>
      );
    }
    return null;
  };

  return (
    <div className="flex flex-col h-full">
      <div className="px-5 pt-14 pb-4">
        <p className="text-[10px] tracking-[0.18em] uppercase" style={{ color: G.green }}>Progress</p>
        <h1 className="text-[28px] font-black uppercase"
          style={{ fontFamily: "'Barlow Condensed', sans-serif", color: G.white }}>
          History
        </h1>
      </div>

      <div className="flex-1 overflow-y-auto px-5 pb-6 space-y-4" style={{ scrollbarWidth: "none" }}>

        {/* Headline stats */}
        <div className="grid grid-cols-3 gap-2">
          {[
            { label: "Latest", value: latestScore, color: G.green },
            { label: "Best", value: bestScore, color: G.blue },
            { label: "Average", value: avgScore, color: G.amber },
          ].map(({ label, value, color }) => (
            <div key={label} className="rounded-xl py-3.5 text-center"
              style={{ background: G.card, border: `1px solid ${G.border}` }}>
              <div className="text-[22px] font-black leading-none"
                style={{ fontFamily: "'Barlow Condensed', sans-serif", color }}>
                {value}
              </div>
              <div className="text-[9px] tracking-widest uppercase mt-1" style={{ color: G.muted }}>{label}</div>
            </div>
          ))}
        </div>

        {/* Chart */}
        <div className="rounded-2xl p-4" style={{ background: G.card, border: `1px solid ${G.border}` }}>
          <div className="flex items-start justify-between mb-3">
            <div>
              <p className="text-[10px] font-black tracking-widest uppercase" style={{ color: G.muted }}>Score Over Time</p>
              <p className="text-[11px] mt-0.5" style={{ color: G.green }}>
                +14 pts across 6 sessions
              </p>
            </div>
            <div className="text-right">
              <p className="text-[10px]" style={{ color: G.muted }}>Most improved</p>
              <p className="text-[11px] font-bold mt-0.5" style={{ color: G.green }}>{mostImproved}</p>
            </div>
          </div>
          <ResponsiveContainer width="100%" height={110}>
            <AreaChart data={chartData} margin={{ top: 4, right: 4, left: -28, bottom: 0 }}>
              <defs>
                <linearGradient id="sg" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor={G.green} stopOpacity={0.25} />
                  <stop offset="95%" stopColor={G.green} stopOpacity={0} />
                </linearGradient>
              </defs>
              <XAxis dataKey="label" tick={{ fill: G.muted, fontSize: 9 }} axisLine={false} tickLine={false} />
              <YAxis domain={[55, 90]} tick={{ fill: G.muted, fontSize: 9 }} axisLine={false} tickLine={false} />
              <Tooltip content={<CustomTooltip />} />
              <Area type="monotone" dataKey="score" stroke={G.green} strokeWidth={2.5}
                fill="url(#sg)"
                dot={{ fill: G.green, strokeWidth: 0, r: 3 }}
                activeDot={{ r: 5, fill: G.green, stroke: G.bg, strokeWidth: 2 }} />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Filters */}
        <div className="flex gap-2">
          {filters.map(f => (
            <button key={f} onClick={() => setFilter(f)}
              className="px-3.5 py-1.5 rounded-full text-[11px] font-bold tracking-wide transition-all"
              style={{
                background: filter === f ? G.greenDim : G.card,
                color: filter === f ? G.green : G.muted,
                border: `1px solid ${filter === f ? G.greenBorder : G.border}`,
              }}>
              {f}
            </button>
          ))}
        </div>

        {/* Session list */}
        <div className="space-y-2">
          {sessions.map(({ score, date, delta, label }, i) => (
            <div key={i} className="flex items-center gap-3.5 rounded-xl px-4 py-3.5 transition-all active:scale-[0.98] cursor-pointer"
              style={{ background: G.card, border: `1px solid ${G.border}` }}>
              <div className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0"
                style={{ background: G.greenDim, border: `1px solid ${G.greenBorder}` }}>
                <span className="text-[18px]">⚽</span>
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-[13px] font-semibold" style={{ color: G.white }}>{label} · Shooting</p>
                <p className="text-[11px] mt-0.5" style={{ color: G.muted }}>{date}</p>
              </div>
              <div className="text-right flex-shrink-0">
                <div className="text-[18px] font-black leading-none"
                  style={{ fontFamily: "'Barlow Condensed', sans-serif", color: G.white }}>
                  {score}<span className="text-[11px] font-normal" style={{ color: G.muted }}>/100</span>
                </div>
                {delta !== null && (
                  <div className="text-[10px] font-bold mt-0.5"
                    style={{ color: delta > 0 ? G.green : G.red }}>
                    {delta > 0 ? `↑ +${delta}` : `↓ ${delta}`}
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
      <NavBar active="history" onNav={go} />
    </div>
  );
}

function ProfileScreen({ go }: { go: (s: Screen) => void }) {
  const fields = [
    { label: "Age Group", value: "Under-17" },
    { label: "Position", value: "Centre Forward" },
    { label: "Dominant Foot", value: "Right" },
    { label: "Training Level", value: "Intermediate" },
    { label: "Club / Academy", value: "FC Academy" },
  ];

  return (
    <div className="flex flex-col h-full">
      <div className="flex-1 overflow-y-auto" style={{ scrollbarWidth: "none" }}>
        {/* Header */}
        <div className="relative overflow-hidden px-5 pt-14 pb-7"
          style={{ background: `linear-gradient(165deg, #0B1430 0%, ${G.bg} 100%)` }}>
          <FieldGrid opacity={0.04} />
          <GlowOrb top="0" right="0" size={200} opacity={0.09} />
          <div className="relative flex items-center gap-4">
            <div className="relative w-16 h-16 rounded-2xl flex items-center justify-center text-3xl"
              style={{
                background: `linear-gradient(135deg, #162040, ${G.card})`,
                border: `1.5px solid ${G.greenBorder}`,
              }}>
              ⚽
              <div className="absolute -bottom-1 -right-1 w-5 h-5 rounded-full flex items-center justify-center"
                style={{ background: G.green }}>
                <Check size={10} color={G.bg} strokeWidth={3} />
              </div>
            </div>
            <div>
              <h2 className="text-[24px] font-black uppercase leading-tight"
                style={{ fontFamily: "'Barlow Condensed', sans-serif", color: G.white }}>
                Marcus Silva
              </h2>
              <div className="flex items-center gap-1.5 mt-1">
                <Star size={10} color={G.amber} fill={G.amber} />
                <span className="text-[11px] font-semibold" style={{ color: G.amber }}>Intermediate · U-17</span>
              </div>
              <p className="text-[10px] mt-0.5" style={{ color: G.muted }}>Member since June 2025</p>
            </div>
          </div>
        </div>

        <div className="px-5 pb-6 space-y-4 mt-4">
          {/* Stats */}
          <div className="grid grid-cols-2 gap-2.5">
            {[
              { label: "Total Sessions", value: "6", color: G.green },
              { label: "Avg Score", value: "73/100", color: G.blue },
              { label: "Best Score", value: "84/100", color: G.amber },
              { label: "Most Analyzed", value: "Shooting", color: G.purple },
            ].map(({ label, value, color }) => (
              <div key={label} className="rounded-xl p-3.5"
                style={{ background: G.card, border: `1px solid ${G.border}` }}>
                <div className="text-[17px] font-black"
                  style={{ fontFamily: "'Barlow Condensed', sans-serif", color }}>{value}</div>
                <div className="text-[10px] mt-0.5" style={{ color: G.muted }}>{label}</div>
              </div>
            ))}
          </div>

          {/* Profile fields */}
          <div className="rounded-2xl overflow-hidden"
            style={{ background: G.card, border: `1px solid ${G.border}` }}>
            <div className="px-4 py-3" style={{ borderBottom: `1px solid ${G.border}` }}>
              <p className="text-[10px] font-black tracking-widest uppercase" style={{ color: G.muted }}>
                Player Profile
              </p>
            </div>
            {fields.map(({ label, value }, i) => (
              <div key={label} className="flex items-center justify-between px-4 py-3.5"
                style={{ borderBottom: i < fields.length - 1 ? `1px solid ${G.border}` : "none" }}>
                <span className="text-[12px]" style={{ color: G.muted }}>{label}</span>
                <span className="text-[12px] font-semibold" style={{ color: G.white }}>{value}</span>
              </div>
            ))}
          </div>

          {/* Actions */}
          <div className="space-y-2.5">
            <button className="w-full flex items-center gap-4 rounded-2xl px-4 py-4 transition-all active:scale-[0.98]"
              style={{ background: `${G.red}0E`, border: `1px solid ${G.red}22` }}>
              <div className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0"
                style={{ background: `${G.red}18` }}>
                <Trash2 size={15} color={G.red} />
              </div>
              <div className="text-left">
                <p className="text-[13px] font-bold" style={{ color: G.red }}>Delete Uploaded Videos</p>
                <p className="text-[11px] mt-0.5" style={{ color: `${G.red}88` }}>
                  Remove all stored video data from this device
                </p>
              </div>
            </button>
            <button className="w-full flex items-center gap-4 rounded-2xl px-4 py-4 transition-all active:scale-[0.98]"
              style={{ background: G.card, border: `1px solid ${G.border}` }}>
              <div className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0"
                style={{ background: G.card2 }}>
                <Settings size={15} color={G.muted} />
              </div>
              <div className="text-left flex-1">
                <p className="text-[13px] font-bold" style={{ color: G.white }}>Settings</p>
                <p className="text-[11px] mt-0.5" style={{ color: G.muted }}>Notifications, privacy, account</p>
              </div>
              <ChevronRight size={14} color={G.muted} />
            </button>
          </div>

          <p className="text-center text-[10px] pt-1" style={{ color: G.muted }}>
            KickAI Coach · MVP v1.0 · Shooting Module
          </p>
        </div>
      </div>
      <NavBar active="profile" onNav={go} />
    </div>
  );
}

// ─── SCREEN REGISTRY ────────────────────────────────────────────────────────
const SCREENS: { id: Screen; label: string }[] = [
  { id: "splash", label: "Splash" },
  { id: "dashboard", label: "Home" },
  { id: "shooting-guide", label: "Guide" },
  { id: "video-upload", label: "Upload" },
  { id: "processing", label: "Processing" },
  { id: "results", label: "Results" },
  { id: "history", label: "History" },
  { id: "profile", label: "Profile" },
];

// ─── APP ROOT ────────────────────────────────────────────────────────────────
export default function App() {
  const [screen, setScreen] = useState<Screen>("splash");
  const [key, setKey] = useState(0);

  function go(s: Screen) {
    setScreen(s);
    setKey(k => k + 1);
  }

  const renderScreen = () => {
    switch (screen) {
      case "splash": return <SplashScreen go={go} />;
      case "dashboard": return <DashboardScreen go={go} />;
      case "shooting-guide": return <ShootingGuideScreen go={go} />;
      case "video-upload": return <VideoUploadScreen go={go} />;
      case "processing": return <ProcessingScreen go={go} />;
      case "results": return <ResultsScreen go={go} />;
      case "history": return <HistoryScreen go={go} />;
      case "profile": return <ProfileScreen go={go} />;
      default: return null;
    }
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-start gap-5 pt-6 pb-8 px-4"
      style={{ background: "#030509" }}>

      {/* Navigation strip */}
      <div className="flex flex-wrap gap-1.5 max-w-[420px] justify-center">
        {SCREENS.map(({ id, label }) => (
          <button key={id} onClick={() => go(id)}
            className="px-3 py-1 rounded-full text-[10px] font-bold tracking-wide transition-all"
            style={{
              background: screen === id ? G.greenDim : "#0C1126",
              color: screen === id ? G.green : G.muted,
              border: `1px solid ${screen === id ? G.greenBorder : "rgba(255,255,255,0.05)"}`,
              fontFamily: "'JetBrains Mono', monospace",
            }}>
            {String(SCREENS.findIndex(s => s.id === id) + 1).padStart(2, "0")} {label}
          </button>
        ))}
      </div>

      {/* Phone frame */}
      <div className="relative flex-shrink-0"
        style={{
          width: 390,
          height: 790,
          borderRadius: 50,
          background: G.card,
          boxShadow: [
            "0 0 0 10px #0C1126",
            "0 0 0 11px rgba(46,232,107,0.06)",
            "0 48px 96px rgba(0,0,0,0.85)",
            `inset 0 0 0 1px rgba(255,255,255,0.04)`,
          ].join(", "),
        }}>

        {/* Notch */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 z-50 w-28 h-8 rounded-b-[24px]"
          style={{ background: "#0C1126" }} />

        {/* Status bar mockup */}
        <div className="absolute top-2 left-8 right-8 z-50 flex items-center justify-between px-1"
          style={{ height: 20 }}>
          <span className="text-[10px] font-bold" style={{ color: G.whiteDim, fontFamily: "'DM Sans', sans-serif" }}>
            9:41
          </span>
          <div className="flex items-center gap-1.5 opacity-70">
            <div className="flex items-end gap-0.5 h-3">
              {[3, 5, 7, 9].map((h, i) => (
                <div key={i} className="w-1 rounded-sm" style={{ height: h, background: G.white }} />
              ))}
            </div>
            <svg width="14" height="10" viewBox="0 0 14 10">
              <rect x="1" y="3" width="10" height="7" rx="1.5" fill="none" stroke={G.white} strokeWidth="1.2" />
              <rect x="2" y="4" width="7" height="5" rx="0.8" fill={G.white} />
              <rect x="11.5" y="4.5" width="1.5" height="3" rx="0.5" fill={G.white} />
            </svg>
          </div>
        </div>

        {/* Screen content */}
        <div key={key} className="absolute inset-0 overflow-hidden"
          style={{ borderRadius: 50, background: G.bg }}>
          {renderScreen()}
        </div>

        {/* Home indicator */}
        <div className="absolute bottom-2.5 left-1/2 -translate-x-1/2 w-28 h-1 rounded-full z-50"
          style={{ background: "rgba(255,255,255,0.2)" }} />
      </div>

      <p className="text-[9px] tracking-[0.2em] uppercase"
        style={{ color: "#1A2340", fontFamily: "'JetBrains Mono', monospace" }}>
        KickAI Coach · Shooting Module · MVP Prototype
      </p>
    </div>
  );
}
